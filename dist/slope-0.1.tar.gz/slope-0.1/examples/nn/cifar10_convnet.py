import slope


import slope.nn as nn

import time
import numpy as np
from tqdm import tqdm

import numpy as np
from lib.datasets.cifar10 import get_cifar10
from lib.models.cv.resnet_cifar import resnet


@slope.jit
def train_step(model, batch, optimizer):
    def train_loss_fn(model, batch):
        x, y = batch
        logits, model = model(x, training=True)
        loss = -(logits.log_softmax() * y).sum()
        return loss, (model, logits)
    (loss, (model, logits)), grad_model = slope.value_and_grad(train_loss_fn, has_aux=True)(model, batch)
    model, new_optimizer = optimizer(model, grad_model)
    return loss, logits, model, new_optimizer

@slope.jit
def test_step(model, batch):
    x, y = batch
    logits = model(x, training=False)
    loss = -(logits.log_softmax() * y).sum()
    return loss, logits
# def test():
#     model.eval()
  
#     for data, target in test_loader:
#         if args.cuda:
#             data, target = data.cuda(), target.cuda()
#         data, target = Variable(data, volatile=True), Variable(target)
#         output = model(data)
#         test_loss += F.cross_entropy(output, target, size_average=False).data[0] # sum up batch loss
#         pred = output.data.max(1, keepdim=True)[1] # get the index of the max log-probability
#         correct += pred.eq(target.data.view_as(pred)).cpu().sum()

#     test_loss /= len(test_loader.dataset)
#     print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.1f}%)\n'.format(
#         test_loss, correct, len(test_loader.dataset),
#         100. * correct / len(test_loader.dataset)))
#     return correct / float(len(test_loader.dataset))


def get_dataloader(dataset, batch_size, transforms_fn, shuffle=False):
    perm = np.random.permutation(num_train) if shuffle else np.arange(num_train)
    for i in range(num_batches):
        batch_idx = perm[i * batch_size : (i + 1) * batch_size]
        x = transforms_fn(slope.tensor(train_images[batch_idx]))
        y_onehot = slope.tensor(train_labels[batch_idx]).one_hot(10).cast(slope.float32)
        yield x, y_onehot

def train_transforms_fn(x):
    mean = slope.tensor([0.4914, 0.4822, 0.4465])[None, ..., None, None]
    std = slope.tensor([0.2023, 0.1994, 0.2010])[None, ..., None, None]
    return (x - mean) / std


def test_transforms_fn(x, mean, std):
    mean = slope.tensor([0.4914, 0.4822, 0.4465])[None, ..., None, None]
    std = slope.tensor([0.2023, 0.1994, 0.2010])[None, ..., None, None]
    return (x - mean) / std

if __name__ == "__main__":
    num_epochs = 50
    train_batch_size = 50  # TODO: must be multiple of dataset
    test_batch_size = 50 
    train_images, train_labels, test_images, test_labels = get_cifar10()
    num_train = train_images.shape[0]
    num_complete_batches, leftover = divmod(num_train, train_batch_size)
    num_batches = num_complete_batches + bool(leftover)
    model = resnet(depth=8)
    optimizer = nn.Adam(model, lr=1e-3)
    
    train_dataloader = get_dataloader(train_images, train_batch_size, train_transforms_fn, shuffle=True)
    test_dataloader = get_dataloader(test_images, test_batch_size, test_transforms_fn, shuffle=True)

    print("\nStarting training...")
    best_acc = 0.
    for epoch in range(num_epochs):
        start_time = time.time()
        train_loss = slope.zeros(())
        train_accuracy = slope.zeros(())
        for i, batch in (pbar := tqdm(enumerate(train_dataloader))):
            loss, logits, model, optimizer = train_step(model, batch, optimizer)
            train_loss = train_loss + loss
            y_hat, y =  logits.argmax(-1), batch[1].argmax(-1)
            train_accuracy = train_accuracy + (y_hat == y).cast(slope.float32)
            N = train_batch_size * (i+1)
            msg = f"Train epoch: {epoch}, batch: {i}/{num_batches}, loss: {(train_loss.numpy()/N):.2f}, acc: {(train_accuracy.numpy()/N):.2f}"
            pbar.set_description(msg)
        epoch_time = time.time() - start_time
        test_loss = 0.
        test_accuracy = 0.
        for i, batch in (pbar := tqdm(enumerate(test_dataloader))):
            loss, logits, model, optimizer = train_step(model, batch, optimizer)
            test_loss = test_loss + loss
            y_hat, y =  logits.argmax(-1), batch[1].argmax(-1)
            test_accuracy = test_accuracy + (y_hat == y).cast(slope.float32)
            N = train_batch_size * (i+1)
            msg = f"Test epoch: {epoch}, batch: {i}/{num_batches}, loss: {(train_loss.numpy()/N):.2f}, acc: {(train_accuracy.numpy()/N):.2f}"
            pbar.set_description(msg)
    corrects = (y_hat == y)
    accuracy = corrects.mean().numpy()

