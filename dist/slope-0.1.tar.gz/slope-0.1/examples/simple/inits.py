import slope

a = slope.arange(5)
print(a)